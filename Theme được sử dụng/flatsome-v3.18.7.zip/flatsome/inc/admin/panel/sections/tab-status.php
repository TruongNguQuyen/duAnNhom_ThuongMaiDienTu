<?php
/**
 * Status tab.
 *
 * @package Flatsome\Admin
 */

?>
<div id="tab-status">
	<?php Flatsome\Admin\status()->render_panel(); ?>
</div>
